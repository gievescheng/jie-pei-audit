"""
wafer_spc/api/import_api.py
============================
CSV 量測資料匯入的後端 API。

對應前端三步驟介面：
  Step 1（上傳設定）  → 前端處理，不需後端
  Step 2（預覽驗證）  → validate_csv()
  Step 3（確認匯入）  → submit_import()

所有函式均以 @frappe.whitelist() 裝飾，前端透過 frappe.call() 呼叫。
"""

from __future__ import annotations
import frappe
from frappe import _
from typing import Optional


# ─────────────────────────────────────────────────────────────
#  規格預設值（若前端未傳入則使用此值）
# ─────────────────────────────────────────────────────────────
DEFAULT_SPEC = {
    "thickness_usl": 705.0,
    "thickness_lsl": 695.0,
    "ttv_usl":       2.0,
    "ttv_lsl":       0.0,
    "particle_max":  500,   # Particle Count 上限（每顆 Wafer）
}

# CSV 欄位名稱（設備輸出的固定 header）
COL_WAFER_ID   = "Wafer ID"
COL_THICKNESS  = "Thickness Avg(um)"
COL_TTV        = "TTV(um)"
COL_PARTICLE   = "Particle Count"   # 可能不存在


# ─────────────────────────────────────────────────────────────
#  Step 2：驗證（不寫入任何資料）
# ─────────────────────────────────────────────────────────────

@frappe.whitelist()
def validate_csv(
    csv_data: list[dict],
    work_order: str,
    batch_id: str,
    spec: Optional[dict] = None,
) -> dict:
    """
    解析並驗證 CSV 資料，回傳驗證結果。
    不寫入任何 ERPNext 文件。

    Parameters
    ----------
    csv_data   : 前端 Papa.parse() 解析後的 list[dict]
    work_order : ERPNext Work Order 編號
    batch_id   : 批號（對應 ERPNext Batch）
    spec       : 規格字典，未傳入則使用 DEFAULT_SPEC

    Returns
    -------
    {
        "valid": bool,
        "errors": list[str],          # 阻擋匯入的錯誤
        "warnings": list[str],        # 警告但不阻擋
        "total": int,
        "oos_count": int,
        "oos_rows": list[dict],       # [{wafer_id, thickness, ttv, reasons}]
        "rows": list[dict],           # 清洗後的全部資料
        "preflight": dict,            # 工單/批號狀態檢查結果
    }
    """
    _spec = {**DEFAULT_SPEC, **(spec or {})}
    errors: list[str] = []
    warnings: list[str] = []
    rows: list[dict] = []
    oos_rows: list[dict] = []

    # ── 1. 工單狀態檢查 ──────────────────────────────────────
    preflight = _check_work_order(work_order)
    if not preflight["ok"]:
        errors.append(preflight["message"])

    # ── 2. 欄位解析 + 唯一性 ─────────────────────────────────
    seen_ids: set[str] = set()

    for i, raw in enumerate(csv_data, start=1):
        row_errors: list[str] = []

        # Wafer ID
        wid = str(raw.get(COL_WAFER_ID, "")).strip()
        if not wid:
            errors.append(f"第 {i} 列：Wafer ID 為空")
            continue
        if wid in seen_ids:
            errors.append(f"Wafer ID 重複：{wid}（第 {i} 列）")
            continue
        seen_ids.add(wid)

        # Thickness
        thickness = _safe_float(raw.get(COL_THICKNESS), COL_THICKNESS, i, row_errors)

        # TTV
        ttv = _safe_float(raw.get(COL_TTV), COL_TTV, i, row_errors)

        # Particle（選填）
        particle_raw = raw.get(COL_PARTICLE)
        particle = _safe_float(particle_raw, COL_PARTICLE, i, []) if particle_raw not in (None, "", "N/A", "--") else None

        errors.extend(row_errors)
        if row_errors:
            continue

        clean_row = {
            "wafer_id":  wid,
            "thickness": thickness,
            "ttv":       ttv,
            "particle":  particle,
        }
        rows.append(clean_row)

        # ── 3. OOS 判定 ───────────────────────────────────────
        reasons: list[str] = []
        t, v = thickness, ttv
        if t is not None:
            if t > _spec["thickness_usl"]:
                reasons.append(f"Thickness {t:.3f} > USL {_spec['thickness_usl']} (+{t - _spec['thickness_usl']:.3f})")
            elif t < _spec["thickness_lsl"]:
                reasons.append(f"Thickness {t:.3f} < LSL {_spec['thickness_lsl']} ({t - _spec['thickness_lsl']:.3f})")
        if v is not None:
            if v > _spec["ttv_usl"]:
                reasons.append(f"TTV {v:.3f} > USL {_spec['ttv_usl']} (+{v - _spec['ttv_usl']:.3f})")
        if particle is not None and particle > _spec["particle_max"]:
            reasons.append(f"Particle {int(particle)} > max {_spec['particle_max']}")

        if reasons:
            oos_rows.append({**clean_row, "reasons": reasons})

    return {
        "valid":     len(errors) == 0,
        "errors":    errors,
        "warnings":  warnings,
        "total":     len(rows),
        "oos_count": len(oos_rows),
        "oos_rows":  oos_rows,
        "rows":      rows,
        "preflight": preflight,
    }


# ─────────────────────────────────────────────────────────────
#  Step 3：實際寫入 ERPNext
# ─────────────────────────────────────────────────────────────

@frappe.whitelist()
def submit_import(
    validated_rows: list[dict],
    work_order: str,
    batch_id: str,
    spec: Optional[dict] = None,
    oos_action: str = "include_rejected",
) -> dict:
    """
    將驗證後的資料寫入 ERPNext Quality Inspection。

    Parameters
    ----------
    validated_rows : validate_csv() 回傳的 rows（已清洗）
    work_order     : ERPNext Work Order 編號
    batch_id       : 批號
    spec           : 規格字典
    oos_action     : "include_rejected" | "exclude_oos" | "include_notify"

    Returns
    -------
    {
        "qi_name": str,          # 建立的 QI 文件編號
        "total_written": int,    # 寫入的 Wafer 數
        "accepted": int,
        "rejected": int,
    }
    """
    _spec = {**DEFAULT_SPEC, **(spec or {})}

    # ── 建立 Quality Inspection ───────────────────────────────
    qi = frappe.new_doc("Quality Inspection")
    qi.work_order      = work_order
    qi.batch_no        = batch_id
    qi.inspection_type = "In Process"
    qi.item_code       = frappe.db.get_value("Work Order", work_order, "production_item")
    # TODO: 確認你們的 ERPNext 是否有 inspector 欄位，如有需填入 frappe.session.user

    accepted = 0
    rejected = 0

    for row in validated_rows:
        t   = row["thickness"]
        ttv = row["ttv"]

        t_ok   = _spec["thickness_lsl"] <= t   <= _spec["thickness_usl"]
        ttv_ok = _spec["ttv_lsl"]       <= ttv <= _spec["ttv_usl"]
        overall_ok = t_ok and ttv_ok

        if oos_action == "exclude_oos" and not overall_ok:
            continue  # 剔除模式：OOS 不寫入

        t_status   = "Accepted" if t_ok   else "Rejected"
        ttv_status = "Accepted" if ttv_ok else "Rejected"

        qi.append("readings", {
            "specification": "Thickness",
            "reading_1":     t,
            "status":        t_status,
            # TODO: 確認 ERPNext v15 readings 子表的實際欄位名稱
            # 可能需要加 "wafer_id": row["wafer_id"] 作為備註
        })
        qi.append("readings", {
            "specification": "TTV",
            "reading_1":     ttv,
            "status":        ttv_status,
        })

        if overall_ok:
            accepted += 1
        else:
            rejected += 1

    qi.insert()
    qi.submit()
    # qi.submit() 會觸發 after_submit hook → spc_engine.run_all_charts()

    # oos_action == "include_notify" 的通知邏輯
    if oos_action == "include_notify" and rejected > 0:
        _send_oos_notification(qi.name, rejected, work_order)

    return {
        "qi_name":      qi.name,
        "total_written": accepted + rejected,
        "accepted":     accepted,
        "rejected":     rejected,
    }


# ─────────────────────────────────────────────────────────────
#  工具函式
# ─────────────────────────────────────────────────────────────

def _check_work_order(work_order: str) -> dict:
    """檢查工單是否存在且狀態允許匯入"""
    if not frappe.db.exists("Work Order", work_order):
        return {"ok": False, "message": f"工單 {work_order} 不存在"}

    status = frappe.db.get_value("Work Order", work_order, "status")
    allowed = ("Not Started", "In Progress")
    if status not in allowed:
        return {
            "ok": False,
            "message": f"工單 {work_order} 狀態為「{status}」，無法寫入（允許：{allowed}）"
        }

    return {"ok": True, "status": status, "message": "OK"}


def _safe_float(
    val,
    field_name: str,
    row_num: int,
    errors: list[str],
) -> Optional[float]:
    """安全轉換為 float，失敗時寫入 errors 並回傳 None"""
    if val is None or str(val).strip() in ("", "N/A", "--", "null"):
        errors.append(f"第 {row_num} 列「{field_name}」為空值")
        return None
    try:
        return float(str(val).strip())
    except (ValueError, TypeError):
        errors.append(f"第 {row_num} 列「{field_name}」無法轉為數值：'{val}'")
        return None


def _send_oos_notification(qi_name: str, oos_count: int, work_order: str) -> None:
    """
    發送 ERPNext in-app Notification 給品保主管角色。
    TODO: 確認你們的品保主管角色名稱（Role 名稱）
    """
    # TODO: 替換為實際的品保主管 Role 或 User
    qc_users = frappe.get_all(
        "Has Role",
        filters={"role": "Quality Manager"},   # 確認 Role 名稱
        fields=["parent"],
    )
    for u in qc_users:
        frappe.publish_realtime(
            event="spc_oos_alert",
            message={
                "qi_name":    qi_name,
                "oos_count":  oos_count,
                "work_order": work_order,
            },
            user=u.parent,
        )
