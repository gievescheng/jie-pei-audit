"""
wafer_spc/doctype/quality_inspection/quality_inspection.py
===========================================================
ERPNext Quality Inspection 的 Controller 擴充。

after_submit：QI 提交後自動觸發 SPC 計算並更新 SPC Chart DocType。

Frappe hooks.py 需加入：
    doc_events = {
        "Quality Inspection": {
            "after_submit": "wafer_spc.doctype.quality_inspection.quality_inspection.after_submit",
        }
    }
"""

from __future__ import annotations
import json
import frappe
from wafer_spc.spc_engine import run_all_charts


# 規格設定（TODO：未來從 Item 的 Item Quality Inspection Parameter 讀取）
DEFAULT_SPEC = {
    "thickness_usl": 705.0,
    "thickness_lsl": 695.0,
    "ttv_usl":       2.0,
    "ttv_lsl":       0.0,
}


def after_submit(doc, method=None):
    """
    Quality Inspection submit 後觸發 SPC 計算。
    只處理 inspection_type == "In Process" 的 QI（製程中檢驗）。
    """
    if doc.inspection_type != "In Process":
        return

    # ── 從 readings 子表提取量測值 ────────────────────────────
    thickness_values = [
        r.reading_1 for r in doc.readings
        if r.specification == "Thickness" and r.reading_1 is not None
    ]
    ttv_values = [
        r.reading_1 for r in doc.readings
        if r.specification == "TTV" and r.reading_1 is not None
    ]

    if not thickness_values and not ttv_values:
        frappe.log_error(
            message=f"QI {doc.name} 沒有 Thickness 或 TTV readings，跳過 SPC 計算",
            title="SPC Engine: No Data"
        )
        return

    # ── 取得本月 Particle 批次資料（Laney u' 使用）────────────
    particle_lots = _get_particle_lots_this_month(doc)

    # ── 執行 SPC 計算 ─────────────────────────────────────────
    try:
        result = run_all_charts(
            thickness_values=thickness_values,
            ttv_values=ttv_values,
            particle_lots=particle_lots,
            spec=DEFAULT_SPEC,
        )
    except Exception as e:
        frappe.log_error(
            message=frappe.get_traceback(),
            title=f"SPC Engine Error: {doc.name}"
        )
        return

    # ── 更新 SPC Chart DocType ────────────────────────────────
    if result.get("thickness"):
        _upsert_spc_chart("thickness_imr", result["thickness"], doc)

    if result.get("ttv"):
        _upsert_spc_chart("ttv_imr", result["ttv"], doc)

    if result.get("particle"):
        _upsert_spc_chart("particle_laney_u", result["particle"], doc)

    # ── 失控訊號警報 ──────────────────────────────────────────
    if result.get("summary", {}).get("needs_attention"):
        _send_spc_alert(result["summary"], doc)


def _get_particle_lots_this_month(doc) -> list[dict]:
    """
    取得本月（與 doc 同月）所有已提交 QI 的 Particle 批次資料。

    每個 Work Order 視為一批（lot），
    計算該 Work Order 中 Particle 規格超標的 Wafer 數。

    TODO: Particle Count 目前存在 readings 的哪個欄位？
    若 specification == "Particle"，reading_1 是總計數還是超規件數？
    需要確認後調整邏輯。
    """
    from datetime import datetime

    month_start = datetime.today().replace(day=1).strftime("%Y-%m-%d")

    # 取得本月所有 In Process QI（同料號）
    qi_list = frappe.get_all(
        "Quality Inspection",
        filters={
            "inspection_type": "In Process",
            "docstatus":        1,               # 已提交
            "item_code":        doc.item_code,
            "creation":         [">=", month_start],
        },
        fields=["name", "work_order", "batch_no"],
    )

    lots = []
    for qi_meta in qi_list:
        qi_doc = frappe.get_doc("Quality Inspection", qi_meta.name)

        # 本批 Wafer 數（以 Thickness readings 數量計）
        n = sum(1 for r in qi_doc.readings if r.specification == "Thickness")
        if n == 0:
            continue

        # 本批 Particle 超規件數
        # TODO: 確認 Particle 的存法後調整
        # 方案 A：若有 specification == "Particle"，reading_1 > 500 計為超規
        # 方案 B：若 Particle 存在其他 Custom Field
        particle_oos = sum(
            1 for r in qi_doc.readings
            if r.specification == "Particle" and r.status == "Rejected"
        )

        lots.append({
            "lot_id":  qi_meta.name,
            "n":       n,
            "defects": particle_oos,
        })

    return lots


def _upsert_spc_chart(chart_id: str, chart_data: dict, qi_doc) -> None:
    """
    更新或建立 SPC Chart 文件。
    若該 chart_id + item_code 的文件已存在則更新，否則新建。

    TODO: SPC Chart DocType 需先建立（見 CLAUDE.md 的欄位定義）
    """
    existing = frappe.db.get_value(
        "SPC Chart",
        {"chart_id": chart_id, "item_code": qi_doc.item_code},
        "name",
    )

    cap = chart_data.get("capability", {})
    meta = chart_data.get("meta", {})

    fields = {
        "chart_id":            chart_id,
        "chart_type":          chart_data.get("chart_type", ""),
        "item_code":           qi_doc.item_code,
        "work_order":          qi_doc.work_order,
        "x_bar":               chart_data.get("x_bar") or chart_data.get("u_bar"),
        "ucl":                 (chart_data.get("x_ucl") or
                                (chart_data.get("ucl", [None])[0] if chart_data.get("ucl") else None)),
        "lcl":                 (chart_data.get("x_lcl") or
                                (chart_data.get("lcl", [None])[0] if chart_data.get("lcl") else None)),
        "sigma":               chart_data.get("sigma_mr"),
        "cpk":                 cap.get("cpk"),
        "cp":                  cap.get("cp"),
        "sample_count":        chart_data.get("n") or chart_data.get("n_lots"),
        "has_ooc":             meta.get("has_ooc", False),
        "ooc_count":           meta.get("ooc_count_x") or meta.get("ooc_count", 0),
        "data_json":           json.dumps(chart_data, ensure_ascii=False),
        "nelson_signals_json": json.dumps(chart_data.get("nelson_signals", {}), ensure_ascii=False),
        "last_updated":        frappe.utils.now_datetime(),
    }

    if existing:
        doc = frappe.get_doc("SPC Chart", existing)
        doc.update(fields)
        doc.save(ignore_permissions=True)
    else:
        doc = frappe.new_doc("SPC Chart")
        doc.update(fields)
        doc.insert(ignore_permissions=True)


def _send_spc_alert(summary: dict, qi_doc) -> None:
    """
    發送 SPC 失控警報。
    目前以 frappe.publish_realtime 推送前端通知；
    TODO: 可改為 Email Alert 或 ERPNext Notification Log。
    """
    message = {
        "qi_name":        qi_doc.name,
        "work_order":     qi_doc.work_order,
        "thickness_cpk":  summary.get("thickness_cpk"),
        "ttv_cpk":        summary.get("ttv_cpk"),
        "any_ooc":        summary.get("any_ooc"),
        "any_nelson":     summary.get("any_nelson"),
    }

    # 推送給所有線上的品保角色使用者
    qc_users = frappe.get_all(
        "Has Role",
        filters={"role": "Quality Manager"},  # TODO: 確認 Role 名稱
        fields=["parent"],
        pluck="parent",
    )
    for user in qc_users:
        frappe.publish_realtime(
            event="spc_alert",
            message=message,
            user=user,
        )

    frappe.log_error(
        message=json.dumps(message, indent=2, ensure_ascii=False),
        title=f"SPC Alert: {qi_doc.name}",
    )
