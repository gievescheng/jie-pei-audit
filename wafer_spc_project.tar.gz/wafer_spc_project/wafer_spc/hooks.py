app_name = "wafer_spc"
app_title = "Wafer SPC"
app_publisher = "Your Company"
app_description = "SPC 統計製程管制系統，適用於玻璃晶圓清洗製程"
app_email = "admin@yourcompany.com"
app_license = "MIT"

doc_events = {
    "Quality Inspection": {
        "after_submit": (
            "wafer_spc.doctype.quality_inspection"
            ".quality_inspection.after_submit"
        ),
    }
}

# TODO: 若需要在 Measurement Import DocType 提交時觸發驗證，加入：
# "Measurement Import": {
#     "before_submit": "wafer_spc.api.import_api.before_submit_measurement_import",
# }
