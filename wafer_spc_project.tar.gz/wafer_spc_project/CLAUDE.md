# Wafer SPC — Claude Code Handoff 文件

## 專案背景

台灣某半導體玻璃晶圓清洗廠，產線流程：
**OCR → 超音波清洗 → 清洗機 → 目檢 → TTV → AOI → 包裝**

目標：在 **ERPNext（Frappe Framework）** 上建立一個 Custom App `wafer_spc`，
實現 CSV 量測資料匯入 → Quality Inspection 紀錄 → SPC 管制圖自動更新的完整閉環。

---

## 已完成的部分（本 repo 已有）

### `wafer_spc/spc_engine.py` ✅ 完整可用
三種管制圖的計算核心，**已通過全部測試**，不需要修改：

| 函式 | 用途 |
|---|---|
| `run_imr(values, usl, lsl)` | Thickness / TTV 的 I-MR 管制圖 |
| `run_laney_u(lot_counts)` | Particle 計數的 Laney u' 管制圖 |
| `calc_capability(values, usl, lsl)` | Cp / Cpk / Cpm 製程能力指數 |
| `run_all_charts(thickness, ttv, lots, spec)` | 一次觸發三張圖的整合進入點 |

回傳值均為純 dict，可直接 JSON 序列化存入 ERPNext DocType。

---

## 需要 Claude Code 完成的部分

### 優先順序 1：CSV 匯入後端 API

**檔案**：`wafer_spc/api/import_api.py`

需實作兩個 `@frappe.whitelist()` 函式：

```python
def validate_csv(csv_data, work_order, batch_id, spec) -> dict
def submit_import(validated_rows, work_order, batch_id, oos_action) -> dict
```

**`validate_csv` 必須做的檢查（照順序）：**
1. 工單狀態是否為 `In Progress` 或 `Not Started`
2. Wafer ID 唯一性（同一批次不重複，跨 CSV 合併也要查）
3. 必要欄位是否齊全：`Wafer ID`、`Thickness Avg(um)`、`TTV(um)`
4. 數值欄位可否轉 float（空值、`N/A`、`--` 等要捕捉）
5. OOS 統計（依傳入的 spec 計算）
6. 若存在 Particle 欄位（`Particle Count`）也一併統計

回傳格式：
```python
{
    "valid": bool,
    "errors": ["錯誤訊息"],
    "warnings": ["警告訊息"],
    "total": int,
    "oos_count": int,
    "oos_rows": [{"wafer_id": ..., "thickness": ..., "ttv": ..., "reasons": [...]}],
    "rows": [{"wafer_id", "thickness", "ttv", "particle"}],
}
```

**`submit_import` 的寫入邏輯：**

```python
# 建立 Quality Inspection
qi = frappe.new_doc("Quality Inspection")
qi.work_order    = work_order
qi.batch_no      = batch_id
qi.inspection_type = "In Process"
qi.item_code     = frappe.db.get_value("Work Order", work_order, "production_item")

# 每個 Wafer 對應兩筆 Reading（Thickness + TTV）
for row in validated_rows:
    qi.append("readings", {
        "specification": "Thickness",
        "reading_1": row["thickness"],
        "status": "Accepted" if lsl <= row["thickness"] <= usl else "Rejected",
    })
    qi.append("readings", {
        "specification": "TTV",
        "reading_1": row["ttv"],
        "status": "Accepted" if row["ttv"] <= ttv_usl else "Rejected",
    })

qi.insert()
qi.submit()   # submit 會觸發 after_submit hook → SPC 計算
```

`oos_action` 的三種值：
- `"include_rejected"` — 全部匯入，OOS 標 Rejected（**預設**）
- `"exclude_oos"` — 只匯入規格內的，OOS 筆不寫入
- `"include_notify"` — 全部匯入 + 發 ERPNext Notification 給品保主管

---

### 優先順序 2：after_submit Hook 串接 SPC

**檔案**：`wafer_spc/doctype/quality_inspection/quality_inspection.py`

```python
import frappe
from wafer_spc.spc_engine import run_all_charts

def after_submit(doc, method=None):
    thickness = [r.reading_1 for r in doc.readings if r.specification == "Thickness"]
    ttv       = [r.reading_1 for r in doc.readings if r.specification == "TTV"]

    # particle_lots：從同月份所有 QI 歷史批次彙總
    # 格式：[{"lot_id": "QI-xxx", "n": 600, "defects": 3}, ...]
    particle_lots = _get_particle_lots_this_month(doc)

    spec = {
        "thickness_usl": 705.0, "thickness_lsl": 695.0,
        "ttv_usl": 2.0,         "ttv_lsl": 0.0,
    }

    result = run_all_charts(thickness, ttv, particle_lots, spec)

    # 結果存入 SPC Chart DocType（見下方定義）
    _upsert_spc_chart("thickness_imr", result["thickness"], doc)
    _upsert_spc_chart("ttv_imr",       result["ttv"],       doc)
    _upsert_spc_chart("particle_laney", result["particle"],  doc)

    # 若有失控訊號，發 Notification
    if result["summary"]["needs_attention"]:
        _send_spc_alert(result["summary"], doc)
```

---

### 優先順序 3：SPC Chart DocType

**檔案**：`wafer_spc/doctype/spc_chart/spc_chart.json`

需要的欄位清單：

| 欄位名 | 型別 | 說明 |
|---|---|---|
| `chart_id` | Data | 主鍵識別碼（如 `thickness_imr`） |
| `chart_type` | Select | `I-MR` / `Laney u'` |
| `item_code` | Link → Item | 產品料號 |
| `work_order` | Link → Work Order | |
| `x_bar` | Float | 中心線 |
| `ucl` | Float | 管制上限 |
| `lcl` | Float | 管制下限 |
| `sigma` | Float | 估計標準差 |
| `cpk` | Float | 製程能力指數 |
| `cp` | Float | |
| `last_updated` | Datetime | |
| `data_json` | Long Text | 完整 run_imr/run_laney_u 回傳的 JSON |
| `has_ooc` | Check | 是否有失控點 |
| `ooc_count` | Int | 失控點數量 |
| `nelson_signals_json` | Long Text | Nelson Rules 觸發結果 JSON |
| `sample_count` | Int | 累計樣本數 |

---

### 優先順序 4：Measurement Import DocType（CSV 匯入介面）

**檔案**：`wafer_spc/doctype/measurement_import/`

這個 DocType 是 CSV 匯入流程的 ERPNext 入口，對應 UI 設計中的三步驟流程：

欄位：
- `work_order` — Link → Work Order
- `batch_id` — Data
- `import_date` — Date（自動填今日）
- `csv_files` — Attach Multiple（允許上傳多個 CSV）
- `spec_thickness_usl/lsl` — Float（預設帶入 Item 的 spec）
- `spec_ttv_usl/lsl` — Float
- `oos_action` — Select（三個選項）
- `status` — Select：`Draft` / `Validated` / `Imported`
- `validation_result_json` — Long Text（步驟 2 的驗證結果）
- `qi_name` — Link → Quality Inspection（匯入後自動填入）
- `total_rows` / `accepted_count` / `rejected_count` — Int

---

### 優先順序 5：前端管制圖渲染

**檔案**：`wafer_spc/public/js/spc_chart.js`

從 SPC Chart DocType 讀 `data_json`，用 Frappe 內建的 `frappe.Chart`（基於 Chart.js）渲染：
- X chart 折線 + UCL/LCL 水平線 + OOC 點紅色標記
- MR chart（I-MR 專用）
- 點擊 OOC 點顯示 Tooltip：Wafer ID + 量測值 + 超出多少

---

## 資料格式參考

### 設備輸出 CSV 欄位（實際檔案格式）

```csv
Wafer ID,Thickness Avg(um),TTV(um),Particle Count
NKAAE120AFD4,702.025,0.282,0
NKAAE120AFD5,701.340,0.195,1
NKAAE121B6F3,705.692,0.318,0
```

- `Wafer ID`：刻號，格式 `NKAAE` + 6碼英數字
- `Thickness Avg(um)`：平均厚度，正常範圍 695–705 μm
- `TTV(um)`：Total Thickness Variation，正常範圍 0–2 μm
- `Particle Count`：可能不存在（部分設備不輸出此欄）

### Excel FOSB 清單欄位對應（供 FOSB 報表產生參考）

```python
FOSB_COLUMN_MAP = [
    {"wafer_id": "C",  "thickness": "E",  "ttv": "F"},   # FOSB1
    {"wafer_id": "I",  "thickness": "K",  "ttv": "L"},   # FOSB2
    {"wafer_id": "O",  "thickness": "Q",  "ttv": "R"},   # FOSB3
    {"wafer_id": "U",  "thickness": "W",  "ttv": "X"},   # FOSB4
    {"wafer_id": "AA", "thickness": "AC", "ttv": "AD"},  # FOSB5
    {"wafer_id": "AG", "thickness": "AI", "ttv": "AJ"},  # FOSB6
]
DATA_START_ROW = 5
```

---

## 技術規格

- **ERPNext 版本**：v15（Frappe Framework v15）
- **Python**：3.11+
- **相依套件**：`numpy`、`scipy`（需加入 `requirements.txt`）
- **DB**：MariaDB 10.6+（Frappe 標準）
- **部署**：Frappe Cloud 或自架 bench（Taiwan 伺服器）

### 安裝指令（bench 環境）

```bash
cd ~/frappe-bench
bench get-app wafer_spc https://github.com/your-org/wafer_spc
bench --site your-site.localhost install-app wafer_spc
bench migrate
```

---

## 規格限制與注意事項

1. **SPC 管制界限更新策略**：目前設計為「每次 QI submit 重新計算所有歷史資料」。
   當樣本數超過 500 批時需考慮改為「滑動窗口（最近 N 批）」模式。

2. **Particle Laney u' 的批次定義**：每個 Work Order（一個 FOSB 箱）視為一批，
   `n` = 該箱的 Wafer 數，`defects` = 該箱的 Particle 超規 Wafer 數。
   **不是每個 Wafer 的 Particle 計數，是每箱的超規件數。**

3. **OOS Wafer 的庫存動作**：OOS 標記 Rejected 後，目前設計不自動移轉庫存至「不合格品倉」，
   需由品保人員手動在 ERPNext 做 Stock Entry（Material Transfer）。
   未來可考慮在 `_send_spc_alert` 中自動建立 Stock Entry draft。

4. **多 CSV 合併的 Wafer ID 唯一性**：同一個 Work Order 可能有來自 TTV 設備和 Thickness 設備
   的兩個 CSV，兩者的 Wafer ID 應該完全相同（同一批晶圓）。
   若有任何 ID 只出現在一個 CSV，要列為 Warning 而非 Error。

5. **ERPNext Quality Inspection 的 readings 子表**：
   每個 Wafer 對應**兩筆** readings（Thickness 一筆 + TTV 一筆），
   共 445 Wafer × 2 = 890 筆 readings，Frappe 可以一次 insert，效能可接受。

---

## 已討論但尚未實作的功能（未來 Phase）

- **FOSB 清單 Print Format**：從 QI 自動生成客戶 Excel 格式報表
- **SPC 管制圖前端互動**：點擊 OOC 點顯示 Wafer 詳情
- **批次歷史趨勢儀表板**：跨多個 Work Order 的月趨勢圖
- **設備 CSV 格式自動識別**：不同型號設備輸出格式不同，需自動 detect header
- **繁體中文 i18n**：ERPNext 官方支援，需建立 `translations/zh.csv`
